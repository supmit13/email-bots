# This module contains various utility functions.

import os, sys, re, time
import GeoIP
import socket
import socks
import StringIO
import mimetypes, mimetools

urlPattern = re.compile(r"^https?:\/\/([^\/]+)/?.*$", re.IGNORECASE)

def getUrlDirPathFromUrl(url):
    urlParts = url.split("/")
    urlPath = "/".join(urlParts[0:-1])
    return (urlPath)


def getCountryNameFromIP(ipaddr):
    gi = GeoIP.new(GeoIP.GEOIP_MEMORY_CACHE)
    return(gi.country_name_by_addr(ipaddr))


def getIPAddrFromUrl(urlStr):
    urlSearch = urlPattern.search(urlStr)
    if urlSearch:
	hostname = urlSearch.groups()[0]
	return(socket.gethostbyname(hostname))
    else:
	return None


# Read a configuration file with the following basic format:
# Each line contains a config parameter and its value of the form 'param=value'.
# Parameter names may not contain spaces. Values may contain spaces and should
# always be terminated by newline character or '#' character (comment character).
# Parameter names and values are separated by a '=' sign. Whitespaces around the
# '=' sign are trimmed when the line is processed by this function. Whitespace
# characters may also be present at the start and end of a line. These are also
# trimmed while processing the line. Lines may also contain comments. Comments
# always start with '#'. Everything succeeding a '#' character is ignored by 
# this function. Lines may also be empty (containing 0 or more spaces). Comments 
# lines and empty lines are ignored during processing.
def readBasicConfig(cfgfile):
    if not os.path.exists(cfgfile) or not os.path.isfile(cfgfile):
	print "Config file ('%s') does not exist. Please specify the full path to the config file as the first argument of your program if it is not in the default location.\n"
	return(None)
    fcfg = open(cfgfile)
    configContents = fcfg.read()
    fcfg.close()
    config = {}
    configLines = configContents.split("\n")
    commentPattern = re.compile(r"^#")
    for line in configLines:
	line = line.strip()
	commentSearch = commentPattern.search(line)
	if line == "" or commentSearch:
	    continue
	param, value = line.split("=")
	param = param.strip()
	value = value.strip()
	valuesparts = list(value.split("#"))
	if valuesparts.__len__() > 1:
	    value = valuesparts[0].strip()
	    config[param] = value
	else:
	    config[param] = value
    return(config)



def dumpCsvHeader(filehndl):
    if (filehndl.mode != 'w' and filehndl.mode != 'wb') or filehndl.closed == True:
	print "_dumpCsv: filehandle is unusable.\n"
	return None
    headerline = ""
    for attrib in cls._supported_attribs:
	headerline += attrib + ","
    headerline = headerline[:-1] + "\n"
    filehndl.write(headerline)
    return(headerline)



def dumpCsvData(filehandle):
    if (filehandle.mode != 'w' and filehandle.mode != 'wb') or filehandle.closed == True:
	print "_dumpCsv: filehandle is unusable.\n"
	return None
    else:
	line = ""
	for attrib in self.__class__.supportedAttributes():
	    line += "\"" + self.__dict__[attrib.lower()] + "\","
	line = line[0:-1]
	uline = line.encode('utf-8') # handle unicode
	filehandle.write(uline + "\n")
    return (uline + "\n")

    
def dumpXmlData(self, filehandle):
    if (filehandle.mode != 'w' and filehandle.mode != 'wb') or filehandle.closed == True:
	print "_dumpXml: filehandle is unusable.\n"
	return None
    else:
	pass # Handle the data here


# Implement signal handler for ctrl+c here.
def setSignal():
    pass


# Test script.
if __name__ == "__main__":
    cfg = readBasicConfig("../config/GmailBot.cfg")
    for cfgkey in cfg.keys():
	print cfgkey + " ======= " + cfg[cfgkey]
    print "Done!"
    
